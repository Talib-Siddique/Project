﻿using Infosys.AmigoWalletDAL.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Infosys.AmigoWalletDAL
{
    public class AmigoWalletRepository
    {
        private readonly AmigoWalletContext _context;

        public AmigoWalletRepository(AmigoWalletContext context)
        {
            _context = context;
        }

        //AmigoWalletContext context;
        //public AmigoWalletRepository()
        //{
        //    context = new AmigoWalletContext();
        //}

        //Login validation
        public bool ValidateCredentials(String EmailId, String Password)
        {
            bool status = false;
            var user = _context.User.Where(e => e.EmailId == EmailId).FirstOrDefault();
            if (user != null && user.Password == Password)
                status = true;
            else
                status = false;
            return status;
        }

        //Register user
        public int RegisterUser(string Name, String EmailId, String MobileNumber, String Password)
        {
            int status;
            try
            {
                if (_context.User.Where(e => e.EmailId == EmailId).Any())
                    status = 0;
                else
                {
                    User userObj = new User();
                    userObj.Name = Name;
                    userObj.EmailId = EmailId;
                    userObj.MobileNumber = MobileNumber;
                    userObj.Password = Password;
                    userObj.CreatedTimestamp = DateTime.Now;
                    userObj.ModifiedTimestamp = null;
                    userObj.StatusId = 1;

                    _context.User.Add(userObj);
                    _context.SaveChanges();
                    status = 1;
                }
            }
            catch (Exception ex)
            {
                status = -99;
            }
            return status;
        }

        //Add monet to wallet using card
        public bool AddMoneyToWallet(string CardNumber, int CvvNumber, decimal Amount, DateTime ExpiryDate, int Pin, string EmailId, bool IsChecked)
        {
            try
            {
                Amount = Math.Round(Amount, 2);
                if(CardNumber.Length == 16 && CvvNumber.ToString().Length == 3 && Pin.ToString().Length == 4 && Amount > 0 && ExpiryDate > DateTime.Now)
                {
                    if(IsChecked && (_context.UserCard.Where(x => x.CardNumber == CardNumber))==null)
                    {
                        UserCard cardObj = new UserCard();
                        cardObj.CardNumber = CardNumber;
                        cardObj.ExpiryDate = ExpiryDate;
                        cardObj.StatusId = 1;
                        cardObj.EmailId = EmailId;
                        cardObj.BankId = 1;
                        cardObj.CreatedTimestamp = DateTime.Now;
                        cardObj.ModifiedTimestamp = null;
                        _context.UserCard.Add(cardObj);
                        _context.SaveChanges();
                    }
                    
                }
                UserTransaction tranObj = new UserTransaction();
                tranObj.EmailId = EmailId;
                tranObj.Amount = Amount;
                tranObj.TransactionDateTime = DateTime.Now;
                tranObj.PaymentTypeId = 3;
                tranObj.Remarks = null;
                tranObj.Info = "NAN";
                tranObj.StatusId = 1;
                tranObj.PointsEarned = 0;
                tranObj.IsRedeemed = false;
                _context.UserTransaction.Add(tranObj);
                _context.SaveChanges();
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
            return false;
        }

        public decimal FetchWalletBalance(string EmailId)
        {
            try
            {
                decimal totalAmount = 0;
                if(_context.UserTransaction.Where(e => e.EmailId == EmailId).Any())
                {
                    List<UserTransaction> userTransactions = _context.UserTransaction.Where(x => x.EmailId == EmailId).ToList();
                    foreach(var tran in userTransactions)
                    {
                        totalAmount += (decimal)tran.Amount;
                    }
                }
                else
                {
                    return -1;
                }
                return totalAmount;
            }
            catch (Exception ex)
            {
                return -99;
            }
        }
    }
}
