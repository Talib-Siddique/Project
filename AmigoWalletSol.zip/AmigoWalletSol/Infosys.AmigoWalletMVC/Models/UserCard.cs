﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Infosys.AmigoWalletMVC.Models
{
    public class UserCard
    {

        //[RegularExpression(@"^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$", ErrorMessage = "Invalid email address.")]
        //[Required(ErrorMessage = "EmailId is mandatory.")]
        //[Display(Name ="Email Id:")]
        //public string EmailId { get; set; }

        [Display(Name = "Card Number:")]
        [Required(ErrorMessage = "Card Number is mandatory.")]
        [RegularExpression(@"^([0-9]{16})$", ErrorMessage = "Invalid Card Number.")]
        public string CardNumber { get; set; }

        [Display(Name = "Cvv:")]
        [Required(ErrorMessage = "Cvv Number is mandatory.")]
        [RegularExpression(@"^([0-9]{3})$", ErrorMessage = "Invalid Cvv Number.")]
        public int CvvNumber { get; set; }

        [Display(Name = "Pin:")]
        [Required(ErrorMessage = "Pin is mandatory.")]
        [RegularExpression(@"^([0-9]{4})$", ErrorMessage = "Invalid Pin.")]
        public int Pin { get; set; }

        [Display(Name = "Expiry Date:")]
        [Required(ErrorMessage = "*")]
        public DateTime ExpiryDate { get; set; }

        [RegularExpression(@"^\d+\.\d{0,2}$")]
        [Range(1, 9999999999999999.99)]
        [Display(Name ="Enter Amount:")]
        [Required(ErrorMessage ="Enter valid amount")]
        public Decimal Amount { get; set; }
        
        [Display(Name ="Save Card")]
        public bool IsChecked { get; set; }

    }
}
