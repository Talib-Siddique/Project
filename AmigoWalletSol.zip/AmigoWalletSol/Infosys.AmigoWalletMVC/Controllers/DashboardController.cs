﻿using Infosys.AmigoWalletDAL;
using Infosys.AmigoWalletDAL.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Infosys.AmigoWalletMVC.Controllers
{
    public class DashboardController : Controller
    {
        private readonly AmigoWalletContext _context;
        AmigoWalletRepository repObj;
        public DashboardController(AmigoWalletContext context)
        {
            _context = context;
            repObj = new AmigoWalletRepository(_context);
        }

        

        public IActionResult User()
        {
            return View();
        }

       public IActionResult AddMoneyToWallet()
        {
            return View();
        }

        public IActionResult SaveAddMoneyToWallet(Models.UserCard cardObj)
        {
            var EmailId = TempData["currentUserEmailId"] as string;
            TempData.Keep("currentUserEmailId");

            try
            {
                
                    var returnValue = repObj.AddMoneyToWallet(cardObj.CardNumber, cardObj.CvvNumber, cardObj.Amount, cardObj.ExpiryDate, cardObj.Pin, EmailId, cardObj.IsChecked);
                    if (returnValue)
                        return View("Success");
                    return Json("DAL Error");
                
            }
            catch (Exception ex)
            {
                return Json("exception error");
            }
            
            
        }

        //Fetch wallet balance
        public IActionResult FetchWalletBalance()
        {
            var EmailId = TempData["currentUserEmailId"] as string;
            TempData.Keep("currentUserEmailId");
            var walletBalance = repObj.FetchWalletBalance(EmailId);
            walletBalance = Math.Round(walletBalance, 2);
            ViewBag.walletBalance = walletBalance;
            return View("User");
        }

        
    }
}
