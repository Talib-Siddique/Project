﻿using Infosys.AmigoWalletDAL;
using Infosys.AmigoWalletDAL.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Infosys.AmigoWalletMVC.Controllers
{
    public class UserController : Controller
    {
        private readonly AmigoWalletContext _context;
        AmigoWalletRepository repObj;
        public UserController(AmigoWalletContext context)
        {
            _context = context;
            repObj = new AmigoWalletRepository(_context);
        }
        public IActionResult LoginRegister()
        {
            return View();
        }

        public IActionResult Login(IFormCollection frm)
        {
            string EmailId = frm["emailId"];
            string Password = frm["pwd"];
            try
            {
                bool status = repObj.ValidateCredentials(EmailId, Password);
                if (status)
                {
                    var name = (from user in _context.User
                               where user.EmailId == EmailId
                               select user.Name).FirstOrDefault();
                    TempData["Name"] = name;
                    TempData["currentUserEmailId"] = EmailId;
                    return RedirectToAction("User", "Dashboard");
                }
                else
                {
                    ViewBag.check = "Invalid Credentials";
                    return View("LoginRegister");
                }
                    
            }
            catch (Exception ex)
            {
                return RedirectToAction("Error", "Home");
            }
            
            return View("LoginRegister");
        }

        public IActionResult Register(Models.User userObj)
        {
            if (ModelState.IsValid)
            {
                var returnValue = repObj.RegisterUser(userObj.Name, userObj.EmailId, userObj.MobileNumber, userObj.Password);
                if (returnValue==1)
                {
                    ViewBag.message = "Successfully Registered";
                    return View("LoginRegister");
                }
                if (returnValue==0)
                {
                    ViewBag.message = "Already Registered";
                    return View("LoginRegister");
                }
                    
                else
                    return View("Error", "Home");
            }
            ViewBag.message = "Enter Valid Details";
            return View("LoginRegister");
            
        }
    }
}
