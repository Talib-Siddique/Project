﻿using System;
using System.Globalization;
using Infosys.AmigoWalletDAL;
using Infosys.AmigoWalletDAL.Models;

namespace Infosys.AmigoWalletConsoleApplication
{
    class Program
    {

        
        static void Main(string[] args)
        {
            //AmigoWalletRepository repository = new AmigoWalletRepository();
            //bool status = repository.ValidateCredentials("gyarnley6@uiuc.edu", "User@12345");
            //if(status)
            //    Console.WriteLine("Valid");
            //else
            //    Console.WriteLine("Invalid");


             void isValid(string dateString)
            {
                CultureInfo ci = new CultureInfo(CultureInfo.CurrentCulture.LCID);
                ci.Calendar.TwoDigitYearMax = 2099; // the end year, so it goes from 2000 to 2099.
                var result = DateTime.ParseExact(dateString, "MM/yy", ci);
                if(result>DateTime.Now)
                    Console.WriteLine("Valid");
                else
                    Console.WriteLine("Invalid");

            }

            isValid("01/22");

            

            //bool status = isValid("01/23");
            //if (status)
            //    Console.WriteLine("valid");
            //else
            //    Console.WriteLine("Invalid");
            
        }
        
    }
}
